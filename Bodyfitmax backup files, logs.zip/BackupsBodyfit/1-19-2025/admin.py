from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User
from .models import UserProfile, WorkoutProgram, WorkoutDay, Exercise, WorkoutExercise, UserWorkout, UserProgress

class UserProfileInline(admin.StackedInline):
    model = UserProfile
    can_delete = False
    verbose_name_plural = 'User Profile'

class CustomUserAdmin(UserAdmin):
    inlines = (UserProfileInline,)

@admin.register(WorkoutProgram)
class WorkoutProgramAdmin(admin.ModelAdmin):
    list_display = ('name', 'target_area', 'difficulty', 'created_at', 'updated_at')
    list_filter = ('difficulty', 'target_area')
    search_fields = ('name', 'description')

@admin.register(WorkoutDay)
class WorkoutDayAdmin(admin.ModelAdmin):
    list_display = ('program', 'name', 'order')
    list_filter = ('program',)
    ordering = ('program', 'order')

@admin.register(Exercise)
class ExerciseAdmin(admin.ModelAdmin):
    list_display = ('name', 'muscle_group', 'equipment_needed')
    list_filter = ('muscle_group',)
    search_fields = ('name', 'description')

@admin.register(WorkoutExercise)
class WorkoutExerciseAdmin(admin.ModelAdmin):
    list_display = ('workout_day', 'exercise', 'sets', 'reps', 'rest_time')
    list_filter = ('workout_day__program', 'exercise__muscle_group')

@admin.register(UserWorkout)
class UserWorkoutAdmin(admin.ModelAdmin):
    list_display = ('user', 'workout_program', 'date', 'completed')
    list_filter = ('completed', 'date', 'workout_program')
    search_fields = ('user__username', 'workout_program__name')

@admin.register(UserProgress)
class UserProgressAdmin(admin.ModelAdmin):
    list_display = ('user', 'date', 'weight', 'body_fat_percentage')
    list_filter = ('user', 'date')
    search_fields = ('user__username',)

admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)