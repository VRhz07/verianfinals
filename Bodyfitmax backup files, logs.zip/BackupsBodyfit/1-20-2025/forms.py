from django import forms
from .models import WorkoutProgram, WorkoutDay, WorkoutExercise, Exercise, UserProfile, UserProgress

class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['date_of_birth', 'height', 'weight', 'fitness_goal', 'activity_level', 'medical_conditions']
        widgets = {
            'date_of_birth': forms.DateInput(attrs={'type': 'date'}),
            'medical_conditions': forms.Textarea(attrs={'rows': 3}),
        }

class WorkoutProgramForm(forms.ModelForm):
    class Meta:
        model = WorkoutProgram
        fields = ['name', 'description', 'target_area', 'difficulty']

class WorkoutDayForm(forms.ModelForm):
    class Meta:
        model = WorkoutDay
        fields = ['name', 'order']

class WorkoutExerciseForm(forms.ModelForm):
    class Meta:
        model = WorkoutExercise
        fields = ['exercise', 'sets', 'reps', 'rest_time']
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['exercise'].queryset = Exercise.objects.all().order_by('name')

class ExerciseForm(forms.ModelForm):
    class Meta:
        model = Exercise
        fields = ['name', 'description', 'equipment_needed', 'muscle_group']

class UserProgressForm(forms.ModelForm):
    class Meta:
        model = UserProgress
        fields = ['date', 'weight', 'body_fat_percentage', 'notes']
        widgets = {
            'date': forms.DateInput(attrs={
                'class': 'w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-blue-500',
                'type': 'date'
            }),
            'weight': forms.NumberInput(attrs={
                'class': 'w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-blue-500',
                'step': '0.1'
            }),
            'body_fat_percentage': forms.NumberInput(attrs={
                'class': 'w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-blue-500',
                'step': '0.1'
            }),
            'notes': forms.Textarea(attrs={
                'class': 'w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-blue-500',
                'rows': 3
            }),
        }
